TALLER ULLOA – FACTURACIÓN (ANDROID)
====================================

Este es el proyecto fuente de una aplicación Android privada, gratuita y sin publicación en Play Store.
No requiere conexión a internet durante el uso y no tiene registro, anuncios ni suscripciones.

FUNCIONES INCLUIDAS
-------------------
- Formulario de cliente, fecha, número de factura, dirección, vehículo y placa.
- Hasta 8 renglones de servicios o repuestos por factura.
- Cálculo automático de cantidad x precio y total.
- Vista previa con el diseño rojo y blanco de Taller Ulloa.
- Guardar facturas en el almacenamiento local de la aplicación.
- Consultar, abrir y eliminar facturas guardadas.
- Guardado automático del borrador mientras se escribe.
- Generar PDF mediante el servicio de impresión de Android (elegir “Guardar como PDF”).
- No se solicita permiso de internet ni se envían datos a servidores.

IMPORTANTE SOBRE LOS DATOS
--------------------------
Las facturas se guardan dentro de los datos privados de la aplicación en el teléfono donde se crean.
No se sincronizan entre teléfonos. Si se desinstala la aplicación o se borran sus datos, las facturas
locales pueden perderse. Guarda los PDF fuera de la aplicación como respaldo.

ESTADO DEL ARCHIVO
------------------
Se entrega el proyecto Android Studio completo, no un APK ya compilado. En el entorno de creación
no está instalado Android SDK/Gradle, así que no es correcto afirmar que se generó un APK instalable.

CÓMO COMPILAR EN ANDROID STUDIO (GRATIS)
----------------------------------------
1. Descomprime el ZIP en una computadora.
2. Instala Android Studio y el SDK de Android API 35.
3. Abre en Android Studio la carpeta “TallerUlloaAndroid”.
4. Usa JDK 17 y Gradle 8.9; deja que Android Studio sincronice el proyecto.
5. Selecciona Build > Build Bundle(s) / APK(s) > Build APK(s).
6. El APK de depuración queda en:
   app/build/outputs/apk/debug/app-debug.apk
7. Copia ese APK a un teléfono Android y permite instalar aplicaciones desde esa fuente.

COMPILACIÓN AUTOMÁTICA CON GITHUB ACTIONS (TAMBIÉN SIN PUBLICAR LA APP)
------------------------------------------------------------------------
El proyecto incluye .github/workflows/build-apk.yml. Tras subir el proyecto a un repositorio de
GitHub, entra a Actions > “Compilar APK Android” > Run workflow. Cuando termine, descarga el
artefacto “Taller-Ulloa-Facturacion-APK”; dentro estará app-debug.apk. GitHub puede aplicar límites
de minutos de compilación según el tipo de cuenta y repositorio.

DATOS TÉCNICOS
--------------
- Nombre: Taller Ulloa – Facturación
- Paquete: com.tallerulloa.facturacion
- Versión: 1.0 (versionCode 1)
- Android mínimo: 6.0 (API 23)
- Android objetivo: API 34
- Compilación: API 35 / Gradle 8.9 / JDK 17
- Interfaz: HTML/CSS/JavaScript local dentro de Android WebView
- PDF: Android PrintManager, tamaño A4
