package com.tallerulloa.facturacion;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.IOException;

public class MainActivity extends Activity {
    private static final String LOCAL_HOST = "appassets.local";
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(142, 29, 32));
        getWindow().setNavigationBarColor(Color.rgb(23, 23, 23));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(238, 241, 245));
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true); // Guarda facturas y borradores en el propio teléfono.
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setLoadsImagesAutomatically(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        webView.addJavascriptInterface(new AndroidBridge(this), "Android");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("https".equalsIgnoreCase(uri.getScheme()) && LOCAL_HOST.equals(uri.getHost())) {
                    String path = uri.getPath();
                    if (path == null || "/".equals(path) || "/index.html".equals(path)) {
                        try {
                            return new WebResourceResponse("text/html", "UTF-8", getAssets().open("index.html"));
                        } catch (IOException ex) {
                            return plainResponse("No se pudo cargar la aplicación.");
                        }
                    }
                    return plainResponse("");
                }
                // La app no realiza conexiones a internet ni carga recursos externos.
                return plainResponse("");
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                return !("https".equalsIgnoreCase(uri.getScheme()) && LOCAL_HOST.equals(uri.getHost()));
            }
        });
        webView.loadUrl("https://" + LOCAL_HOST + "/index.html");
    }

    private WebResourceResponse plainResponse(String value) {
        return new WebResourceResponse("text/plain", "UTF-8",
                new ByteArrayInputStream(value.getBytes(java.nio.charset.StandardCharsets.UTF_8)));
    }

    private class AndroidBridge {
        private final Context context;
        AndroidBridge(Context context) { this.context = context; }

        @JavascriptInterface
        public void printPage() {
            runOnUiThread(() -> {
                try {
                    PrintManager printManager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                    if (printManager == null) {
                        Toast.makeText(context, "No está disponible la impresión en este teléfono.", Toast.LENGTH_LONG).show();
                        return;
                    }
                    String jobName = "Factura_Taller_Ulloa";
                    android.print.PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter(jobName);
                    PrintAttributes attributes = new PrintAttributes.Builder()
                            .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                            .setResolution(new PrintAttributes.Resolution("invoice", "Factura", 300, 300))
                            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                            .build();
                    printManager.print(jobName, adapter, attributes);
                } catch (Exception ex) {
                    Toast.makeText(context, "No se pudo preparar el PDF: " + ex.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("Android");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
